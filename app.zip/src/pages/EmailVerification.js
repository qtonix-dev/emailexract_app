import React from 'react'
import {Container,Grid} from 'semantic-ui-react'

export default function EmailVerification() {
    return (
        <Container>
            <br />
            <br />
            <br />
            <Grid>
                <Grid.Column mobile={16} computer={16}>
                        <center>
                            <img src="https://emailextractonline.com/images/logo-b.png" width="400px" alt="1211" />
                            <h1>Email Verification</h1>

                            

                            
                        </center>
                </Grid.Column>
            </Grid>
            Email Verification
        </Container>
    )
}
