import React, { Component } from 'react'


export default class Stripe extends Component {


    


    render() {
        return (
            // <div style={{display:'none'}}>
            <div>
               
            </div>
        )
    }
}
